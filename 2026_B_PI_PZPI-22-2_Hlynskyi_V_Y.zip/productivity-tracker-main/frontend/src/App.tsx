import { BarChart3, Bell, CheckSquare2, Flame, Home, LogOut, Moon, ShieldCheck, Sun, Trophy, Users, UsersRound, Zap } from "lucide-react";
import { useEffect, useState } from "react";
import { Navigate, NavLink, Route, Routes, useLocation, useNavigate } from "react-router-dom";

import { api, clearTokens, setTokens, subscribeToSessionChanges } from "./api/client";
import { UserAvatar } from "./components/UserAvatar";
import { AchievementsPage } from "./pages/AchievementsPage";
import { AdminPage } from "./pages/AdminPage";
import { AuthPage } from "./pages/AuthPage";
import { DashboardPage } from "./pages/DashboardPage";
import { ForgotPasswordPage } from "./pages/ForgotPasswordPage";
import { GroupsPage } from "./pages/GroupsPage";
import { InboxPage } from "./pages/InboxPage";
import { ProfilePage } from "./pages/ProfilePage";
import { ResetPasswordPage } from "./pages/ResetPasswordPage";
import { StatisticsPage } from "./pages/StatisticsPage";
import { SocialPage } from "./pages/SocialPage";
import { TasksPage } from "./pages/TasksPage";
import { VerifyEmailPage } from "./pages/VerifyEmailPage";
import type { Achievement, Category, RegistrationResponse, Stats, Task, User } from "./types/domain";

const NAV_ITEMS: Array<{
  path: string;
  label: string;
  icon: typeof Home;
  adminOnly?: boolean;
}> = [
  { path: "/today", label: "Today", icon: Home },
  { path: "/tasks", label: "Tasks", icon: CheckSquare2 },
  { path: "/social", label: "Social", icon: Users },
  { path: "/groups", label: "Groups", icon: UsersRound },
  { path: "/progress", label: "Progress", icon: Trophy },
  { path: "/statistics", label: "Statistics", icon: BarChart3 },
  { path: "/admin", label: "Admin", icon: ShieldCheck, adminOnly: true }
];

type Theme = "dark" | "light";

function getInitialTheme(): Theme {
  const savedTheme = window.localStorage.getItem("momentum-theme");
  if (savedTheme === "dark" || savedTheme === "light") return savedTheme;
  return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
}

export function App() {
  const [theme, setTheme] = useState<Theme>(() => {
    const initialTheme = getInitialTheme();
    document.documentElement.dataset.theme = initialTheme;
    return initialTheme;
  });
  const [user, setUser] = useState<User | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const location = useLocation();
  const navigate = useNavigate();
  const isStandaloneAuthRoute = ["/verify-email", "/forgot-password", "/reset-password"].includes(location.pathname);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme;
    window.localStorage.setItem("momentum-theme", theme);
  }, [theme]);

  function toggleTheme() {
    setTheme((currentTheme) => currentTheme === "dark" ? "light" : "dark");
  }

  async function loadWorkspace() {
    setError(null);
    const [me, nextTasks, nextCategories, nextAchievements, nextStats, nextNotifications] = await Promise.all([
      api.me(),
      api.tasks(),
      api.categories(),
      api.achievements(),
      api.statistics(),
      api.notifications()
    ]);
    setUser(me);
    setTasks(nextTasks);
    setCategories(nextCategories);
    setAchievements(nextAchievements);
    setStats(nextStats);
    setUnreadNotifications(nextNotifications.filter((notification) => !notification.is_read).length);
  }

  function resetWorkspaceState() {
    setUser(null);
    setTasks([]);
    setCategories([]);
    setAchievements([]);
    setStats(null);
    setUnreadNotifications(0);
  }

  function clearWorkspace() {
    clearTokens();
    resetWorkspaceState();
  }

  useEffect(() => {
    if (isStandaloneAuthRoute) {
      setLoading(false);
      return;
    }
    api.restoreSession()
      .then((restored) => restored ? loadWorkspace() : undefined)
      .catch(() => clearTokens())
      .finally(() => setLoading(false));
  }, [isStandaloneAuthRoute]);

  useEffect(() => {
    return subscribeToSessionChanges((tokens) => {
      setTokens(tokens);
      resetWorkspaceState();
      loadWorkspace().catch(() => {
        clearWorkspace();
        navigate("/login", { replace: true });
      });
    });
  }, [navigate]);

  useEffect(() => {
    if (!user) return;
    const refreshUnread = () => {
      api.notifications()
        .then((notifications) => setUnreadNotifications(notifications.filter((notification) => !notification.is_read).length))
        .catch(() => undefined);
    };
    const interval = window.setInterval(refreshUnread, 30_000);
    window.addEventListener("focus", refreshUnread);
    return () => {
      window.clearInterval(interval);
      window.removeEventListener("focus", refreshUnread);
    };
  }, [user?.id]);

  async function handleVerifiedSession() {
    resetWorkspaceState();
    await loadWorkspace();
  }

  async function handleLogin(email: string, password: string) {
    setError(null);
    const tokens = await api.login(email, password);
    setTokens(tokens, true);
    await loadWorkspace();
    const requestedPath = (location.state as { from?: string } | null)?.from;
    navigate(requestedPath && requestedPath !== "/login" ? requestedPath : "/today", { replace: true });
  }

  async function handleRegister(
    displayName: string, email: string, password: string
  ): Promise<RegistrationResponse> {
    setError(null);
    return api.register(displayName, email, password);
  }

  async function handleLogout() {
    await api.logout().catch(() => undefined);
    clearWorkspace();
    navigate("/login", { replace: true });
  }

  async function refreshData() {
    try {
      await loadWorkspace();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to refresh data");
    }
  }

  if (loading) return <div className="loading">Loading workspace...</div>;
  if (isStandaloneAuthRoute) {
    return (
      <div className="standalone-route">
        <ThemeToggle className="standalone-theme-toggle" theme={theme} onToggle={toggleTheme} />
        <Routes>
          <Route path="/verify-email" element={<VerifyEmailPage onVerified={handleVerifiedSession} />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />
        </Routes>
      </div>
    );
  }
  if (!user) {
    return (
      <div className="standalone-route">
        <ThemeToggle className="standalone-theme-toggle" theme={theme} onToggle={toggleTheme} />
        <Routes>
          <Route
            path="/login"
            element={<AuthPage onLogin={handleLogin} onRegister={handleRegister} onResend={api.resendVerification} error={error} setError={setError} />}
          />
          <Route path="*" element={<Navigate to="/login" replace state={{ from: location.pathname }} />} />
        </Routes>
      </div>
    );
  }

  const displayName = user.display_name || user.email.split("@")[0];
  const level = stats?.level ?? 1;
  const xp = stats?.xp_total ?? 0;
  const streak = stats?.current_streak ?? 0;
  const visibleNavItems = NAV_ITEMS.filter((item) => !item.adminOnly || user.role === "admin");
  const activeNav = visibleNavItems.find((item) =>
    item.path === "/groups"
      ? location.pathname.startsWith("/groups")
      : location.pathname === item.path
  );
  const activeLabel = location.pathname === "/inbox"
    ? "Inbox"
    : location.pathname === "/profile"
      ? "Profile"
      : activeNav?.label ?? "Today";

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="app-header-inner">
          <div className="brand">
            <span className="brand-mark"><Zap size={19} fill="currentColor" /></span>
            <span className="brand-copy"><strong>Momentum</strong><small>{activeLabel}</small></span>
          </div>
          <nav className="header-nav" aria-label="Primary navigation">
            {visibleNavItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  aria-label={item.label}
                  className={({ isActive }) => isActive ? "active" : ""}
                  end={item.path !== "/groups"}
                  key={item.path}
                  title={item.label}
                  to={item.path}
                >
                  <Icon size={18} />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
          </nav>
          <div className="header-actions">
            <div className="header-progress" title={`${stats?.xp_into_level ?? 0} of ${stats?.xp_for_next_level ?? 0} XP to next level`}>
              <div><strong>Level {level}</strong><span>{xp} XP</span></div>
              <i><b style={{ width: `${stats ? Math.round((stats.xp_into_level / stats.xp_for_next_level) * 100) : 0}%` }} /></i>
            </div>
            <span className="header-streak" title={`${streak} day streak`}><Flame size={15} />{streak}</span>
            <ThemeToggle className="header-theme-toggle" theme={theme} onToggle={toggleTheme} />
            <InboxLink className="header-inbox" unread={unreadNotifications} />
            <NavLink aria-label="Profile" className="header-profile" title="Profile" to="/profile">
              <UserAvatar name={displayName} avatarUrl={user.avatar_url} className="utility-avatar" />
              <span className="header-profile-name">{displayName}</span>
            </NavLink>
            <button className="header-logout" aria-label="Sign out" title="Sign out" onClick={() => void handleLogout()}><LogOut size={17} /></button>
          </div>
        </div>
      </header>
      <div className="workspace">
        <main className="content">
          <div className="content-inner">
            {error && <div className="alert">{error}</div>}
            <Routes>
              <Route path="/" element={<Navigate to="/today" replace />} />
              <Route
                path="/today"
                element={<DashboardPage tasks={tasks} categories={categories} achievements={achievements} stats={stats} onChanged={refreshData} onError={setError} />}
              />
              <Route
                path="/tasks"
                element={<TasksPage tasks={tasks} categories={categories} onChanged={refreshData} onError={setError} />}
              />
              <Route path="/social" element={<SocialPage onError={setError} onUnreadChange={setUnreadNotifications} />} />
              <Route path="/groups" element={<GroupsPage onError={setError} />} />
              <Route path="/groups/:groupId" element={<GroupsPage onError={setError} />} />
              <Route path="/groups/:groupId/:section" element={<GroupsPage onError={setError} />} />
              <Route path="/progress" element={<AchievementsPage tasks={tasks} onChanged={refreshData} onError={setError} />} />
              <Route path="/statistics" element={<StatisticsPage stats={stats} />} />
              <Route path="/admin" element={user.role === "admin" ? <AdminPage onError={setError} /> : <Navigate to="/today" replace />} />
              <Route path="/inbox" element={<InboxPage onError={setError} onUnreadChange={setUnreadNotifications} />} />
              <Route
                path="/profile"
                element={(
                  <ProfilePage
                    user={user}
                    stats={stats}
                    onUserChange={setUser}
                    onDeleted={() => {
                      clearWorkspace();
                      navigate("/login", { replace: true });
                    }}
                    onError={setError}
                  />
                )}
              />
              <Route path="/login" element={<Navigate to="/today" replace />} />
              <Route path="*" element={<Navigate to="/today" replace />} />
            </Routes>
          </div>
        </main>
        <nav className="mobile-nav" aria-label="Mobile navigation">
          {visibleNavItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                aria-label={item.label}
                className={({ isActive }) => isActive ? "active" : ""}
                end={item.path !== "/groups"}
                key={item.path}
                to={item.path}
              >
                <Icon size={20} />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>
    </div>
  );
}

function ThemeToggle({ className, theme, onToggle }: { className: string; theme: Theme; onToggle: () => void }) {
  const nextTheme = theme === "dark" ? "light" : "dark";
  return (
    <button
      aria-label={`Switch to ${nextTheme} theme`}
      className={`theme-toggle ${className}`}
      onClick={onToggle}
      title={`Switch to ${nextTheme} theme`}
      type="button"
    >
      {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}

function InboxLink({ className, unread }: { className: string; unread: number }) {
  return (
    <NavLink aria-label={unread > 0 ? `Inbox, ${unread} unread` : "Inbox"} className={className} title="Inbox" to="/inbox">
      <Bell size={18} />
      {unread > 0 && <b>{unread > 9 ? "9+" : unread}</b>}
    </NavLink>
  );
}
