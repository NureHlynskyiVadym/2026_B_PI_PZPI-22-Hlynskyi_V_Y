import type {
  Achievement,
  AdminSummary,
  AdminUser,
  AdminUserPage,
  AccountabilityCommitment,
  AnalyticsInterval,
  AnalyticsReport,
  Category,
  Challenge,
  FeedPost,
  GamificationDashboard,
  GroupActivity,
  GroupActivityComment,
  GroupAchievement,
  GroupAnalytics,
  GroupChallenge,
  GroupInvitation,
  GroupMilestone,
  GroupProgress,
  GroupTask,
  LeaderboardEntry,
  Person,
  PostComment,
  Profile,
  ProductivityGroup,
  RegistrationResponse,
  SocialNotification,
  Stats,
  Task,
  TokenResponse,
  User,
  VerificationSessionResponse
} from "../types/domain";

const API_URL =
  import.meta.env.VITE_API_URL ??
  `${window.location.protocol}//${window.location.hostname}:8000/api`;
let accessToken: string | null = null;
let refreshPromise: Promise<boolean> | null = null;
const sessionChannel = typeof BroadcastChannel === "undefined"
  ? null
  : new BroadcastChannel("momentum_session");

export function getAccessToken() {
  return accessToken;
}

export function setTokens(tokens: TokenResponse, announce = false) {
  accessToken = tokens.access_token;
  localStorage.removeItem("productivity_access_token");
  localStorage.removeItem("productivity_refresh_token");
  if (announce) {
    sessionChannel?.postMessage(tokens);
  }
}

export function subscribeToSessionChanges(handler: (tokens: TokenResponse) => void) {
  if (!sessionChannel) return () => undefined;
  const listener = (event: MessageEvent<TokenResponse>) => handler(event.data);
  sessionChannel.addEventListener("message", listener);
  return () => sessionChannel.removeEventListener("message", listener);
}

export function clearTokens() {
  accessToken = null;
  localStorage.removeItem("productivity_access_token");
  localStorage.removeItem("productivity_refresh_token");
}

async function refreshAccessToken(): Promise<boolean> {
  if (!refreshPromise) {
    refreshPromise = fetch(`${API_URL}/auth/refresh`, {
      method: "POST",
      credentials: "include"
    })
      .then(async (response) => {
        if (!response.ok) {
          clearTokens();
          return false;
        }
        setTokens(await response.json() as TokenResponse);
        return true;
      })
      .catch(() => {
        clearTokens();
        return false;
      })
      .finally(() => {
        refreshPromise = null;
      });
  }
  return refreshPromise;
}

async function request<T>(
  path: string,
  options: RequestInit = {},
  retryAfterRefresh = true
): Promise<T> {
  const headers = new Headers(options.headers);
  if (!(options.body instanceof FormData)) {
    headers.set("Content-Type", "application/json");
  }
  const token = getAccessToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);

  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers,
    credentials: "include"
  });
  if (response.status === 401 && retryAfterRefresh && !path.startsWith("/auth/")) {
    const refreshed = await refreshAccessToken();
    if (refreshed) return request<T>(path, options, false);
  }
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.detail ?? "Request failed");
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

export const api = {
  register: (displayName: string, email: string, password: string) =>
    request<RegistrationResponse>("/auth/register", {
      method: "POST",
      body: JSON.stringify({ display_name: displayName, email, password })
    }),
  login: (email: string, password: string) =>
    request<TokenResponse>(
      "/auth/login",
      { method: "POST", body: JSON.stringify({ email, password }) },
      false
    ),
  restoreSession: () => refreshAccessToken(),
  logout: () => request<void>("/auth/logout", { method: "POST" }, false),
  verifyEmail: (token: string) =>
    request<VerificationSessionResponse>(
      "/auth/verify-email",
      { method: "POST", body: JSON.stringify({ token }) },
      false
    ).then((session) => {
      if (session.access_token && session.token_type && session.expires_in) {
        setTokens(session as TokenResponse, true);
      }
      return session;
    }),
  verifyEmailCode: (email: string, code: string) =>
    request<VerificationSessionResponse>(
      "/auth/verify-email-code",
      { method: "POST", body: JSON.stringify({ email, code }) },
      false
    ).then((session) => {
      if (session.access_token && session.token_type && session.expires_in) {
        setTokens(session as TokenResponse, true);
      }
      return session;
    }),
  resendVerification: (email: string) =>
    request<{ message: string; verification_url: string | null }>(
      "/auth/resend-verification",
      { method: "POST", body: JSON.stringify({ email }) },
      false
    ),
  forgotPassword: (email: string) =>
    request<{ message: string; verification_url: string | null }>(
      "/auth/forgot-password",
      { method: "POST", body: JSON.stringify({ email }) },
      false
    ),
  resetPassword: (token: string, newPassword: string) =>
    request<{ message: string }>("/auth/reset-password", {
      method: "POST",
      body: JSON.stringify({ token, new_password: newPassword })
    }, false),
  resetPasswordCode: (email: string, code: string, newPassword: string) =>
    request<{ message: string }>("/auth/reset-password-code", {
      method: "POST",
      body: JSON.stringify({ email, code, new_password: newPassword })
    }, false),
  me: () => request<User>("/auth/me"),
  updateMe: (payload: { display_name: string | null; bio: string | null }) =>
    request<User>("/auth/me", { method: "PUT", body: JSON.stringify(payload) }),
  uploadAvatar: (avatar: File) => {
    const form = new FormData();
    form.append("avatar", avatar);
    return request<User>("/auth/me/avatar", { method: "POST", body: form });
  },
  removeAvatar: () => request<User>("/auth/me/avatar", { method: "DELETE" }),
  changePassword: (currentPassword: string, newPassword: string) =>
    request<void>("/auth/change-password", {
      method: "POST",
      body: JSON.stringify({ current_password: currentPassword, new_password: newPassword })
    }),
  deleteAccount: (password: string, confirmation: string) =>
    request<void>("/auth/account", {
      method: "DELETE",
      body: JSON.stringify({ password, confirmation })
    }),
  categories: () => request<Category[]>("/categories"),
  createCategory: (name: string) =>
    request<Category>("/categories", { method: "POST", body: JSON.stringify({ name }) }),
  updateCategory: (id: string, name: string) =>
    request<Category>(`/categories/${id}`, { method: "PUT", body: JSON.stringify({ name }) }),
  deleteCategory: (id: string) => request<void>(`/categories/${id}`, { method: "DELETE" }),
  tasks: () => request<Task[]>("/tasks"),
  createTask: (payload: {
    title: string;
    description?: string;
    priority: string;
    deadline?: string | null;
    scheduled_for?: string | null;
    estimated_minutes?: number | null;
    is_focus?: boolean;
    visibility?: "private" | "public";
    category_id?: string | null;
    parent_id?: string | null;
  }) => request<Task>("/tasks", { method: "POST", body: JSON.stringify(payload) }),
  updateTask: (id: string, payload: Partial<Task>) =>
    request<Task>(`/tasks/${id}`, { method: "PUT", body: JSON.stringify(payload) }),
  completeTask: (id: string) =>
    request<{ task: Task; achievements: Achievement[]; xp_awarded: number }>(`/tasks/${id}/complete`, { method: "POST" }),
  deleteTask: (id: string) => request<void>(`/tasks/${id}`, { method: "DELETE" }),
  achievements: () => request<Achievement[]>("/achievements"),
  createAchievement: (payload: { title: string; description: string; task_id: string }) =>
    request<Achievement>("/achievements", { method: "POST", body: JSON.stringify(payload) }),
  gamification: () => request<GamificationDashboard>("/gamification"),
  statistics: () => request<Stats>("/statistics"),
  profile: () => request<Profile>("/social/profile"),
  updateProfile: (payload: { display_name?: string | null; bio?: string | null; avatar_url?: string | null }) =>
    request<Profile>("/social/profile", { method: "PUT", body: JSON.stringify(payload) }),
  people: () => request<Person[]>("/social/people"),
  leaderboard: () => request<LeaderboardEntry[]>("/social/leaderboard"),
  challenges: () => request<Challenge[]>("/social/challenges"),
  joinChallenge: (id: string) => request<Challenge>(`/social/challenges/${id}/join`, { method: "POST" }),
  leaveChallenge: (id: string) => request<void>(`/social/challenges/${id}/join`, { method: "DELETE" }),
  sendFriendRequest: (id: string) => request<void>(`/social/people/${id}/friend-request`, { method: "POST" }),
  acceptFriendRequest: (id: string) => request<void>(`/social/friend-requests/${id}/accept`, { method: "POST" }),
  declineFriendRequest: (id: string) => request<void>(`/social/friend-requests/${id}`, { method: "DELETE" }),
  removeFriend: (id: string) => request<void>(`/social/people/${id}/friendship`, { method: "DELETE" }),
  feed: () => request<FeedPost[]>("/social/feed"),
  comments: (postId: string) => request<PostComment[]>(`/social/posts/${postId}/comments`),
  createComment: (postId: string, content: string) =>
    request<PostComment>(`/social/posts/${postId}/comments`, {
      method: "POST",
      body: JSON.stringify({ content })
    }),
  deleteComment: (id: string) => request<void>(`/social/comments/${id}`, { method: "DELETE" }),
  react: (id: string) => request<void>(`/social/posts/${id}/reaction`, { method: "POST" }),
  unreact: (id: string) => request<void>(`/social/posts/${id}/reaction`, { method: "DELETE" }),
  notifications: () => request<SocialNotification[]>("/social/notifications"),
  markNotificationsRead: () => request<void>("/social/notifications/read", { method: "POST" }),
  markNotificationRead: (id: string) => request<void>(`/social/notifications/${id}/read`, { method: "POST" }),
  commitments: () => request<AccountabilityCommitment[]>("/social/commitments"),
  inviteAccountability: (taskId: string, partnerId: string) =>
    request<AccountabilityCommitment>(`/social/tasks/${taskId}/accountability`, {
      method: "POST",
      body: JSON.stringify({ partner_id: partnerId })
    }),
  acceptCommitment: (id: string) =>
    request<AccountabilityCommitment>(`/social/commitments/${id}/accept`, { method: "POST" }),
  declineCommitment: (id: string) =>
    request<AccountabilityCommitment>(`/social/commitments/${id}/decline`, { method: "POST" }),
  cancelCommitment: (id: string) => request<void>(`/social/commitments/${id}`, { method: "DELETE" }),
  groups: () => request<ProductivityGroup[]>("/groups"),
  createGroup: (payload: { name: string; description?: string | null }) =>
    request<ProductivityGroup>("/groups", { method: "POST", body: JSON.stringify(payload) }),
  joinGroup: (inviteCode: string) =>
    request<ProductivityGroup>("/groups/join", {
      method: "POST",
      body: JSON.stringify({ invite_code: inviteCode })
    }),
  groupInvitations: () => request<GroupInvitation[]>("/groups/invitations"),
  inviteGroupMember: (groupId: string, userId: string) =>
    request<void>(`/groups/${groupId}/invitations`, {
      method: "POST",
      body: JSON.stringify({ user_id: userId })
    }),
  acceptGroupInvitation: (id: string) =>
    request<void>(`/groups/invitations/${id}/accept`, { method: "POST" }),
  declineGroupInvitation: (id: string) =>
    request<void>(`/groups/invitations/${id}/decline`, { method: "POST" }),
  rotateGroupCode: (id: string) =>
    request<ProductivityGroup>(`/groups/${id}/invite-code`, { method: "POST" }),
  groupTasks: (groupId: string) => request<GroupTask[]>(`/groups/${groupId}/tasks`),
  groupProgress: (groupId: string) => request<GroupProgress>(`/groups/${groupId}/progress`),
  groupActivity: (groupId: string) => request<GroupActivity[]>(`/groups/${groupId}/activity`),
  groupAnalytics: (groupId: string) => request<GroupAnalytics>(`/groups/${groupId}/analytics`),
  groupChallenges: (groupId: string) => request<GroupChallenge[]>(`/groups/${groupId}/challenges`),
  groupAchievements: (groupId: string) => request<GroupAchievement[]>(`/groups/${groupId}/achievements`),
  createGroupChallenge: (groupId: string, payload: { title: string; description?: string | null; target: number; reward_xp: number; ends_at: string }) =>
    request<GroupChallenge>(`/groups/${groupId}/challenges`, {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  deleteGroupChallenge: (challengeId: string) =>
    request<void>(`/groups/challenges/${challengeId}`, { method: "DELETE" }),
  createGroupUpdate: (groupId: string, content: string) =>
    request<GroupActivity>(`/groups/${groupId}/activity`, {
      method: "POST",
      body: JSON.stringify({ content })
    }),
  createGroupActivityComment: (activityId: string, content: string) =>
    request<GroupActivityComment>(`/groups/activity/${activityId}/comments`, {
      method: "POST",
      body: JSON.stringify({ content })
    }),
  deleteGroupActivityComment: (commentId: string) =>
    request<void>(`/groups/activity/comments/${commentId}`, { method: "DELETE" }),
  recognizeGroupActivity: (activityId: string) =>
    request<GroupActivity>(`/groups/activity/${activityId}/recognition`, { method: "POST" }),
  removeGroupActivityRecognition: (activityId: string) =>
    request<void>(`/groups/activity/${activityId}/recognition`, { method: "DELETE" }),
  createGroupTask: (groupId: string, payload: {
    title: string;
    description?: string | null;
    priority: "low" | "medium" | "high";
    deadline?: string | null;
    assigned_to_id: string;
    milestone_id?: string | null;
  }) => request<GroupTask>(`/groups/${groupId}/tasks`, {
    method: "POST",
    body: JSON.stringify(payload)
  }),
  updateGroupTask: (taskId: string, payload: Partial<Pick<GroupTask, "title" | "description" | "priority" | "status" | "deadline" | "assigned_to_id" | "milestone_id">>) =>
    request<GroupTask>(`/groups/tasks/${taskId}`, {
      method: "PUT",
      body: JSON.stringify(payload)
    }),
  deleteGroupTask: (taskId: string) =>
    request<void>(`/groups/tasks/${taskId}`, { method: "DELETE" }),
  groupMilestones: (groupId: string) =>
    request<GroupMilestone[]>(`/groups/${groupId}/milestones`),
  createGroupMilestone: (groupId: string, payload: { title: string; description?: string | null; target_date?: string | null }) =>
    request<GroupMilestone>(`/groups/${groupId}/milestones`, {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  updateGroupMilestone: (milestoneId: string, payload: { title?: string; description?: string | null; target_date?: string | null }) =>
    request<GroupMilestone>(`/groups/milestones/${milestoneId}`, {
      method: "PUT",
      body: JSON.stringify(payload)
    }),
  deleteGroupMilestone: (milestoneId: string) =>
    request<void>(`/groups/milestones/${milestoneId}`, { method: "DELETE" }),
  analytics: (dateFrom: string, dateTo: string, interval: AnalyticsInterval) => {
    const params = new URLSearchParams({
      date_from: dateFrom,
      date_to: dateTo,
      interval
    });
    return request<AnalyticsReport>(`/statistics/analytics?${params}`);
  },
  adminUsers: (query = "", offset = 0, limit = 20) => {
    const params = new URLSearchParams({ query, offset: String(offset), limit: String(limit) });
    return request<AdminUserPage>(`/admin/users?${params}`);
  },
  blockUser: (id: string) =>
    request<AdminUser>(`/admin/users/${id}/block`, { method: "POST" }),
  unblockUser: (id: string) =>
    request<AdminUser>(`/admin/users/${id}/block`, { method: "DELETE" }),
  adminStatistics: () => request<AdminSummary>("/admin/statistics")
};

export function resolveAssetUrl(path: string | null) {
  if (!path) return null;
  if (/^https?:\/\//.test(path)) return path;
  return `${API_URL.replace(/\/api$/, "")}${path.startsWith("/") ? path : `/${path}`}`;
}
